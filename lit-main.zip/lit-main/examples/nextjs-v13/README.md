# Lit in Next.js example

This is a barebones demonstration of a Web Component authored with Lit working
in a Next.js project. You can also see an example of `@lit/react` usage.

It uses the plugin from `@lit-labs/nextjs` to enable deep server rendering of
Lit components.
