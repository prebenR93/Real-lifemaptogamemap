# `@lit/react` components in Preact

This example project demonstrates React components made with `createComponent()`
from `@lit/react` being used in a Preact project.

This also serves as a test project to make sure wrapped components remain
compatible with Preact.
