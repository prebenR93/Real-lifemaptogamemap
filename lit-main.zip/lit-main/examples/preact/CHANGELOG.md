# @lit-examples/preact

## 0.0.1

### Patch Changes

- Updated dependencies []:
  - @lit-internal/test-elements-react@1.0.1

## 0.0.1-pre.0

### Patch Changes

- Updated dependencies []:
  - @lit-internal/test-elements-react@1.0.1-pre.0
