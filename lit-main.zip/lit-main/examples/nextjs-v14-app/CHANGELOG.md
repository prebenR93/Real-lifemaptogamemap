# @lit-examples/nextjs-v14-app

## 0.0.1

### Patch Changes

- Updated dependencies [[`aa4fc3ef`](https://github.com/lit/lit/commit/aa4fc3eff349b202861e597ef7554934b9eaa19a)]:
  - @lit-labs/nextjs@0.2.0
