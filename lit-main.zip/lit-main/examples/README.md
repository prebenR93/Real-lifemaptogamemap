# Lit Examples

This folder contains example projects showcasing usage of `lit` and `@lit-labs`
packages in various contexts, including integrations with other frameworks.

The purpose for these projects includes serving as demonstration or example for
packages in the monorepo, as well as testing to make sure the packages continue
to work in these contexts, and to assist in developing new integrations.
