'use client';

import '../src/simple-greeter';

export default function SimpleGreeter(props: any) {
  return <simple-greeter {...props} />;
}
