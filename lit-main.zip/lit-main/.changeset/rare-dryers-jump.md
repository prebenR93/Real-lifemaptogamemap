---
'@lit-labs/ssr-dom-shim': minor
---

Implement the full CustomElementRegistry type for the ssr shim. Improves fidelity and compilability.
