---
'@lit-labs/virtualizer': patch
'@lit/reactive-element': patch
'@lit-labs/observers': patch
'@lit-labs/signals': patch
'@lit-labs/motion': patch
'lit-element': patch
'lit-html': patch
'@lit/context': patch
'@lit/react': patch
'@lit/task': patch
'lit': patch
---

Update README
