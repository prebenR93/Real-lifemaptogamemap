---
'lit-html': patch
---

Remove some redundant code from removePart()
