---
'@lit-labs/ssr-react': patch
'@lit-labs/nextjs': patch
---

Prevent duplicative patching of React.createElement.
