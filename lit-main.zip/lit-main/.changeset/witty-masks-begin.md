---
'@lit-internal/scripts': patch
---

Fix CI issue regarding release image
