---
'@lit-labs/rollup-plugin-minify-html-literals': minor
---

- Combine `rollup-plugin-minify-html-literals`, `minify-html-literals`, and `parse-literals` into a single package
- Add rollup 4 as a supported peerDependency
