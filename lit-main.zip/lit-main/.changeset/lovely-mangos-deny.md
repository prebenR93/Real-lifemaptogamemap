---
'@lit-labs/vue-utils': patch
---

Fixed an issue where assignSlotNodes would throw an error due to it processing an internal Vue implementation slotname
