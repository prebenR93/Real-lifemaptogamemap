---
'lit': patch
'lit-element': patch
'@lit/reactive-element': patch
---

Fix minor regression in property converters. fromAttribute may return either null or undefined.
