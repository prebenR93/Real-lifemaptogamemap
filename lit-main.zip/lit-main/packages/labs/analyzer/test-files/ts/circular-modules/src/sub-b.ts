import {BaseB} from './base-b.js';
export class SubB extends BaseB {}
