import {BaseB} from './base-b.js';
export class BaseA {
  header: BaseB;
}
