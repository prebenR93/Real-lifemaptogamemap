import {BaseA} from './base-a.js';
export class BaseB {
  accordion: BaseA;
}
