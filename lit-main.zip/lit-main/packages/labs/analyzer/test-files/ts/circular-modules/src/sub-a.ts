import {BaseA} from './base-a.js';
export * from './sub-b.js';
export class SubA extends BaseA {}
