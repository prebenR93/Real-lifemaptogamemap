import ts from 'typescript';
export default ts;
