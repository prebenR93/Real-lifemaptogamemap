// Do not modify this file by hand!
// Re-generate this file by running lit-localize

import {html} from 'lit';

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  he7b474847636149b: html`Hola <b>${0}!</b>`,
};
