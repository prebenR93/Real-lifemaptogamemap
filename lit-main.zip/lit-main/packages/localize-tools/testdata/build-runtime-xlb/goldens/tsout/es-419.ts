// Do not modify this file by hand!
// Re-generate this file by running lit-localize

import {html} from 'lit';
import {str} from '@lit/localize';

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  h349c3c4777670217: html`[SALT] Hola <b>${0}</b>!`,
  h3c44aff2d5f5ef6b: html`Hola <b>Mundo</b>!`,
  h82ccc38d4d46eaa9: html`Hola <b>${0}</b>!`,
  h99e74f744fda7e25: html`Clic <a href="${0}">aquí</a>!`,
  hbe936ff3da20ffdf: html`Hola <b><!-- comment -->Mundo</b>!`,
  hc1c6bfa4414cb3e3: html`[SALT] Clic <a href="${0}">aquí</a>!`,
  myId: `Hola Mundo`,
  s00ad08ebae1e0f74: str`Hola ${0}!`,
  s03c68d79ad36e8d4: `described 0`,
  s0f19e6c4e521dd53: `Mundo`,
  s8c0ec8d1fb9e6e32: `Hola Mundo!`,
};
