This folder is used to test typings in a mixed Lit 2 / Lit 3 installation where the context use sites are using Lit 3, but the context package is using Lit 2.
